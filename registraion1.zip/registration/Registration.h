#ifndef REGISTRATION_H
#define REGISTRATION_H

#include <iostream>
#include <string>
#include "Result.h"

using namespace std;

class Registration {
public:
    Registration();
    unsigned GetCredits() const;
    unsigned GetCount() const;
    long GetStudentId() const;
    unsigned GetSemester() const;
    const Result* GetResults() const;
    void GetResults(unsigned index, Result &result) const;

    void SetCount(unsigned count);
    void SetStudentID(long studentId);
    void SetSemester(unsigned semester);

    friend istream &operator>>(istream &input, Registration &registration);
    friend ostream &operator<<(ostream &os, const Registration &registration);

private:
    long m_studentId;
    unsigned m_semester;
    unsigned m_count;
    Result m_results[10];
};

#endif // REGISTRATION_H
