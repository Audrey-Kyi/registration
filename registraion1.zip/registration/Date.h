#ifndef DATE_H
#define DATE_H

#include <iostream> // Include iostream for istream and ostream

using namespace std;

/**
 * @class Date
 * @brief Represents a date with day, month, and year.
 */
class Date
{
public:
    /**
     * @brief Default constructor for Date.
     */
    Date(); // Default constructor

    /**
     * @brief Parameterized constructor for Date.
     * @param day Day of the date.
     * @param month Month of the date.
     * @param year Year of the date.
     */
    Date(int day, int month, int year); // Parameterized constructor

    /**
     * @brief Gets the day of the date.
     * @return The day.
     */
    int GetDay() const;

    /**
     * @brief Gets the month of the date.
     * @return The month.
     */
    int GetMonth() const;

    /**
     * @brief Gets the year of the date.
     * @return The year.
     */
    int GetYear() const;

    /**
     * @brief Sets the day of the date.
     * @param day The day to set.
     */
    void SetDay(int day);

    /**
     * @brief Sets the month of the date.
     * @param month The month to set.
     */
    void SetMonth(int month);

    /**
     * @brief Sets the year of the date.
     * @param year The year to set.
     */
    void SetYear(int year);

    /**
     * @brief Sets the date.
     * @param day The day to set.
     * @param month The month to set.
     * @param year The year to set.
     */
    void SetDate(int day, int month, int year);

    /**
     * @brief Overloaded input stream operator for Date.
     * @param is Reference to the input stream.
     * @param date Reference to the Date object.
     * @return Reference to the input stream.
     */
    friend istream& operator>>(istream& is, Date& date);

    /**
     * @brief Overloaded output stream operator for Date.
     * @param os Reference to the output stream.
     * @param date Reference to the Date object.
     * @return Reference to the output stream.
     */
    friend ostream& operator<<(ostream& os, const Date& date);

private:
    int m_day;    ///< The day.
    int m_month;  ///< The month.
    int m_year;   ///< The year.
};

#endif // DATE_H
