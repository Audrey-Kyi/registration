#ifndef RESULT_H_INCLUDED
#define RESULT_H_INCLUDED

#include <iostream>
#include "Unit.h"
#include "Date.h"

using namespace std;

class Result {
public:
    Result();       // default constructor
    Result(const Unit &unit, float mark, const Date &date);

    float GetMark() const;
    void GetUnit(Unit &unit) const;
    Date GetDate() const;

    void SetMark(float mark);
    void SetUnit(const Unit &unit);
    void SetDate(const Date &date);

private:
    Unit m_unit;
    float m_mark;
    Date m_date;
};

istream &operator>>(istream &input, Result &result);
ostream &operator<<(ostream &ostr, const Result &result);

#endif // RESULT_H_INCLUDED
