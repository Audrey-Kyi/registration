#include "Result.h"

Result::Result() : m_mark(0) {}

Result::Result(const Unit &unit, float mark, const Date &date)
    : m_unit(unit), m_mark(mark), m_date(date) {}

float Result::GetMark() const {
    return m_mark;
}

void Result::GetUnit(Unit &unit) const {
    unit = m_unit;
}

Date Result::GetDate() const {
    return m_date;
}

void Result::SetMark(float mark) {
    m_mark = mark;
}

void Result::SetUnit(const Unit &unit) {
    m_unit = unit;
}

void Result::SetDate(const Date &date) {
    m_date = date;
}

ostream &operator<<(ostream &ostr, const Result &result) {
    Unit tempUnit;
    result.GetUnit(tempUnit);
    Date tempDate = result.GetDate();

    ostr << tempUnit << "  Marks   : " << result.GetMark() << '\n'
         << "  Date    : " << tempDate << '\n';
    return ostr;
}

istream &operator>>(istream &input, Result &result) {
    Unit tempUnit;
    input >> tempUnit;
    result.SetUnit(tempUnit);

    string data;
    getline(input, data, ',');
    float mark = stof(data);
    result.SetMark(mark);

    int day, month, year;
    getline(input, data, ',');
    day = stoi(data);
    getline(input, data, ',');
    month = stoi(data);
    getline(input, data);
    year = stoi(data);

    Date tempDate(day, month, year);
    result.SetDate(tempDate);

    return input;
}
